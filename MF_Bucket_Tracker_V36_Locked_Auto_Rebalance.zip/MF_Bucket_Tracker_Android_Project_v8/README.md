# MF Bucket Tracker V36 — Locked Auto Rebalancing + Full Article Fix

Based on the uploaded V35 project.

## V36 changes
- Locked **Auto Rebalancing** plan: Calculate/Recalculate creates a fixed snapshot.
- Editing Current Amount after calculation does **not** change the saved plan.
- **Clear Plan** removes the locked snapshot.
- Rebalancing hierarchy: **Bucket level first → fund level inside each bucket**.
- Bucket transfer plan shows exact source → destination and ₹ amount.
- Modes: **Auto — Overweight First**, **Auto — Proportional**, and **Manual Decision**.
- Manual Decision keeps the calculated suggestion but lets the user enter their chosen transfer amount; portfolio values are never auto-edited.
- Shows **New Money Needed** instead of making Gross Movement the primary figure.
- Bucket target defaults fixed to **25% / 25% / 50%** when no target is already saved; existing custom targets are preserved.
- Bucket 1 allocation target is initialized correctly, including profiles created before V36.
- Fund-level calculation is performed only when that bucket's MF Target % totals 100%.
- Current plan becomes visibly marked as stale when Current Amount/Target data changes; it remains locked until Recalculate.
- News **Read Full Article ↗** now opens the verified article URL in the device browser, with WebView fallback.

## Build
Use the supplied GitHub Actions workflow and run it manually or push to `main`.
