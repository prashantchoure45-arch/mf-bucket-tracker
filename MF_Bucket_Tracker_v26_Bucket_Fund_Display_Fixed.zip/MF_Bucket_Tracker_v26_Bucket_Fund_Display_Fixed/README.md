# MF Bucket Tracker v26 — Bucket Fund Display Fix

Built from v25 All Problems Fixed.

## Fix in v26
- Fixed the Bucket 1/2/3 render crash caused by missing `total`, `mfTotal`, and `target` values inside the bucket renderer.
- Bucket fund cards now render after load/add instead of leaving only the static Add form visible.
- Existing Bucket 2 (60/40) and Bucket 3 (40/20/20/15/5) preset funds are preserved.
- Portfolio-level Bucket 1/2/3 target allocation remains separate from each bucket's internal fund allocation.
- No navigation/profile/news architecture changes.

## Build
Open the included Android project in GitHub Actions and run the provided workflow.
