# MF Bucket Tracker V39 — Locked Portfolio Rebalancing Fix

This build is specifically for the Rebalancing workflow.

## Locked portfolio
- Bucket 1: FD only
- Bucket 2: ICICI Prudential Multi-Asset Fund 60% + Parag Parikh Conservative Hybrid Fund 40%
- Bucket 3: Parag Parikh Flexi Cap 40% + Axis Multicap 20% + Invesco India Midcap 20% + Bandhan Small Cap 15% + Invesco Global Equity Income FoF 5%
- DSP World Mining is removed.

## Rebalancing fixes
- Fresh V39 storage key prevents stale V37/V38 portfolio data from overriding the locked structure.
- Fund Target % and Current Amount remain editable.
- Delete button is visible and requires confirmation.
- Rebalancing plan is cleared when Target/Current Amount changes, so stale calculations are not reused.
- Bucket-level and fund-level rebalancing calculations remain calculation-only; current holdings are never changed automatically.
