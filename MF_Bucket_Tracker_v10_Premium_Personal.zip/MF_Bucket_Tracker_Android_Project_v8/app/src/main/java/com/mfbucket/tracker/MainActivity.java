package com.mfbucket.tracker;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile String navTextCache = null;
    private volatile long navCacheTime = 0;
    private static final long CACHE_MS = 30L * 60L * 1000L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView.setFocusableInTouchMode(true);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new NavBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    private class NavBridge {
        @JavascriptInterface public void fetchNav(final String fundName, final int bucket, final int index, final String key) {
            executor.execute(() -> {
                try {
                    String txt = getNavText();
                    String result = findDirectGrowth(txt, fundName);
                    if (result == null) {
                        sendNav(bucket,index,0,"",key,"Direct Growth NAV not found");
                    } else {
                        String[] p = result.split("\\t", -1);
                        sendNav(bucket,index,Double.parseDouble(p[0]),p.length>1?p[1]:"",key,"");
                    }
                } catch (Exception e) {
                    sendNav(bucket,index,0,"",key,"Network/NAV error");
                }
            });
        }
    }

    private String getNavText() throws Exception {
        long now = System.currentTimeMillis();
        if (navTextCache != null && now - navCacheTime < CACHE_MS) return navTextCache;
        URL url = new URL("https://portal.amfiindia.com/spages/NAVAll.txt");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent","MF-Bucket-Tracker/9.0");
        c.connect();
        if (c.getResponseCode()!=200) throw new Exception("HTTP "+c.getResponseCode());
        InputStream in=c.getInputStream();
        BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
        StringBuilder sb=new StringBuilder(); String line;
        while((line=br.readLine())!=null) sb.append(line).append('\n');
        br.close(); c.disconnect();
        navTextCache=sb.toString(); navCacheTime=now;
        return navTextCache;
    }

    private String findDirectGrowth(String text, String wanted) {
        String w = wanted.toLowerCase(Locale.ROOT).replace("fund of fund","fof").replace("fund-of-fund","fof");
        String[] tokens=w.replace("-"," ").replace("/"," ").split("\\s+");
        String best=null; int bestScore=-1;
        String[] lines=text.split("\\r?\\n");
        for(String line:lines){
            if(line.trim().isEmpty()) continue;
            String[] f=line.split(";",-1);
            if(f.length<6 || !f[0].trim().matches("\\d+")) continue;
            String name=f[3].trim(); String lower=name.toLowerCase(Locale.ROOT);
            String plan="", option="", nav="", date="";
            if(f.length>=8){plan=f[4].trim(); option=f[5].trim(); nav=f[f.length-2].trim(); date=f[f.length-1].trim();}
            else {nav=f[4].trim(); date=f[5].trim();}
            if(!lower.contains("direct") || !lower.contains("growth")) continue;
            if(plan.length()>0 && !plan.toLowerCase(Locale.ROOT).contains("direct")) continue;
            if(option.length()>0 && !option.toLowerCase(Locale.ROOT).contains("growth")) continue;
            double nv; try{nv=Double.parseDouble(nav);}catch(Exception e){continue;} if(nv<=0)continue;
            int score=0; for(String t:tokens){if(t.length()>2 && lower.contains(t))score+=2;}
            if(lower.contains("direct plan"))score++; if(lower.contains("growth"))score++;
            if(score>bestScore){bestScore=score;best=nav+"\t"+date;}
        }
        return bestScore>=4?best:null;
    }

    private void sendNav(final int b, final int i, final double nav, final String date, final String key, final String error){
        runOnUiThread(() -> {
            if(webView!=null) {
                String js="window.receiveNav("+b+","+i+","+nav+",'"+escapeJs(date)+"','"+escapeJs(key)+"','"+escapeJs(error)+"');";
                webView.evaluateJavascript(js,null);
            }
        });
    }
    private String escapeJs(String s){return s==null?"":s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ").replace("\r"," ");}

    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
