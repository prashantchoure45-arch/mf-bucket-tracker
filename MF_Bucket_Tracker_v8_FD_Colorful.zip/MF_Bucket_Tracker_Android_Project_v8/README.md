# MF Bucket Tracker v8 — Android APK Project

This project wraps the v8 web/PWA tracker into a native Android WebView app.

## Build on GitHub from a phone
1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Open **Actions** → **Build MF Bucket Tracker APK** → **Run workflow**.
4. When complete, open the workflow run → **Artifacts** → download `MF-Bucket-Tracker-v8-APK`.
5. Extract the artifact and install `app-debug.apk` on Android.

The app stores tracker data locally on the device using browser localStorage inside WebView. Keep backups using the app's Backup/Restore feature.


## v8
Premium colorful UI refresh. Existing Bucket, SIP, Lumpsum, Rebalancing, Returns/CAGR/XIRR, Transactions, Asset Allocation and Goal features are preserved. The existing app icon is retained.

## v8 FD Update
- Added separate Fixed Deposit (FD) tracker.
- Tracks bank/FD name, bucket, principal, current value, interest rate, start date and maturity date.
- FD totals are shown separately from Mutual Funds so MF rebalancing/XIRR calculations are not distorted.
- Estimated interest is only a simple annual estimate; bank statement/certificate remains authoritative.
