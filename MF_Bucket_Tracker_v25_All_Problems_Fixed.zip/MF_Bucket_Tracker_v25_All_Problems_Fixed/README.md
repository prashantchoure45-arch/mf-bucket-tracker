MF Bucket Tracker V25 — All Problems Fixed

Base: V24
Fixes:
- Dedicated News/Profile pages no longer remain under the drawer backdrop, eliminating blur and blocked clicks.
- Profile Add Profile and Change Photo controls work with Android WebView file chooser support.
- Portfolio-level Bucket 1/2/3 target allocation remains 100% total and shows current/target/difference/₹ adjustment.
- Bucket 2/3 fund Add is bucket-safe, validates target totals and duplicate funds, and keeps the added fund visible.
- Bucket 3 current structure uses Invesco Global Equity Income FoF 5% instead of DSP World Mining.
- News queries/source filtering improved and latest items are sorted first.
