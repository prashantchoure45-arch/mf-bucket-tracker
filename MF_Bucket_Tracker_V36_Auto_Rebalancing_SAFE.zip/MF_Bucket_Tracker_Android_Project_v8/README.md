# MF Bucket Tracker V29 — Advanced Allocation & Rebalancing

Built from V28 Fixed Allocation + Rebalancing + Transfer.

## V29 additions
- Larger, easier-to-read Bucket 1/2/3 portfolio allocation cards.
- Automatic Bucket balance box: shows Current %, Target %, exact ₹ add/reduce, and calculated transfer direction (e.g. Bucket 3 → Bucket 1).
- Advanced fund-wise Amount planner with two modes:
  - Add / डालना: splits a new amount across underweight funds according to their current target gaps.
  - Reduce / घटाना: shows exactly how much can be reduced from overweight funds and how the requested reduction should be distributed.
- Existing Current Amount and Target % are never auto-changed by these planners.
- Rebalancing remains calculated only; actual switch/redeem/investment is done separately by the user.
- Indian comma formatting while entering money: 1000000 → 10,00,000.
- Money formatting extended to fund amounts, SIP/Lumpsum, FD, transaction, Goal, Compound and SWP inputs.
- Multi-source/multi-destination transfer planning remains supported when more than one bucket/fund is overweight or underweight.

## Build
Use the supplied GitHub Actions workflow `apk.yml` and upload the V29 ZIP to the repository root.
