# MF Bucket Tracker v7 — Android APK Project

This project wraps the v7 web/PWA tracker into a native Android WebView app.

## Build on GitHub from a phone
1. Create a new GitHub repository.
2. Upload all files/folders from this project.
3. Open **Actions** → **Build MF Bucket Tracker APK** → **Run workflow**.
4. When complete, open the workflow run → **Artifacts** → download `MF-Bucket-Tracker-v7-APK`.
5. Extract the artifact and install `app-debug.apk` on Android.

The app stores tracker data locally on the device using browser localStorage inside WebView. Keep backups using the app's Backup/Restore feature.
