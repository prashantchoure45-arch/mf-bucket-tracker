# MF Bucket Tracker V27 — Bucket Allocation + Fund Display + Rebalancing Fixed

This version keeps the working V26 navigation/features and fixes the bucket/fund workflow.

## Fixed
- Bucket 1/2/3 fund cards are clearly visible.
- Existing funds can be edited; Target % can be changed.
- Fund amount can be entered and current % updates automatically.
- Fund-level target value and rebalancing adjustment update automatically.
- Add Fund still works when there is target room.
- Duplicate fund entry now points to the existing fund instead of creating a second copy.
- Remove Fund asks for confirmation.
- Portfolio-level Bucket 1/2/3 target allocation remains 100% total.
- Portfolio current Bucket % is calculated automatically from actual amounts.
- Portfolio target vs current difference and ₹ adjustment are shown.
- Rebalancing shows portfolio-level bucket adjustment and inside each bucket fund-level adjustment.
- NaN/invalid numeric values are normalized to ₹0 instead of showing ₹NaN.
- Existing V26 navigation, profiles, news, guide, calculators, returns and FD features are preserved.

Default portfolio-level targets: Bucket 1 = 15%, Bucket 2 = 20%, Bucket 3 = 65%.
These are editable and must total 100%.
