package com.mfbucket.tracker;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import android.webkit.JavascriptInterface;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Locale;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private volatile String navTextCache = null;
    private volatile long navCacheTime = 0;
    private static final long CACHE_MS = 30L * 60L * 1000L;
    private ValueCallback<android.net.Uri[]> filePathCallback;
    private static final int FILE_CHOOSER_REQ = 4242;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        webView = new WebView(this);
        setContentView(webView);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        webView.setFocusableInTouchMode(true);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<android.net.Uri[]> callback, FileChooserParams params){
                if(filePathCallback!=null) filePathCallback.onReceiveValue(null);
                filePathCallback=callback;
                try{ Intent intent=params.createIntent(); startActivityForResult(intent,FILE_CHOOSER_REQ); return true; }catch(Exception e){ filePathCallback=null; callback.onReceiveValue(null); return false; }
            }
        });
        webView.addJavascriptInterface(new NavBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==FILE_CHOOSER_REQ){
            if(filePathCallback!=null){
                android.net.Uri[] results=null;
                if(resultCode==RESULT_OK && data!=null){
                    android.net.Uri u=data.getData();
                    if(u!=null) results=new android.net.Uri[]{u};
                }
                filePathCallback.onReceiveValue(results);filePathCallback=null;
            }
        }
    }

    private class NavBridge {
        @JavascriptInterface public void fetchNav(final String fundName, final int bucket, final int index, final String key) {
            executor.execute(() -> {
                try {
                    String txt = getNavText();
                    String result = findDirectGrowth(txt, fundName);
                    if (result == null) {
                        sendNav(bucket,index,0,"",key,"Direct Growth NAV not found");
                    } else {
                        String[] p = result.split("\\t", -1);
                        sendNav(bucket,index,Double.parseDouble(p[0]),p.length>1?p[1]:"",key,"");
                    }
                } catch (Exception e) {
                    sendNav(bucket,index,0,"",key,"Network/NAV error");
                }
            });
        }

        @JavascriptInterface public void fetchNews(final String query) {
            executor.execute(() -> {
                try {
                    String q = URLEncoder.encode(query == null ? "mutual fund India" : query, "UTF-8");
                    URL url = new URL("https://news.google.com/rss/search?q=" + q + "&hl=en-IN&gl=IN&ceid=IN:en");
                    HttpURLConnection c=(HttpURLConnection)url.openConnection();
                    c.setConnectTimeout(15000); c.setReadTimeout(20000); c.setRequestMethod("GET");
                    c.setRequestProperty("User-Agent","MF-Bucket-Tracker/22.0"); c.connect();
                    if(c.getResponseCode()!=200) throw new Exception("HTTP "+c.getResponseCode());
                    BufferedReader br=new BufferedReader(new InputStreamReader(c.getInputStream(),"UTF-8"));
                    StringBuilder sb=new StringBuilder(); String line; while((line=br.readLine())!=null) sb.append(line).append('\n'); br.close(); c.disconnect();
                    String json=parseTrustedNews(sb.toString());
                    runOnUiThread(() -> { if(webView!=null) webView.evaluateJavascript("window.receiveNews("+quoteJs(json)+");",null); });
                } catch(Exception e) {
                    runOnUiThread(() -> { if(webView!=null) webView.evaluateJavascript("window.receiveNews('[]');",null); });
                }
            });
        }

        @JavascriptInterface public void openUrl(final String url) {
            if(url==null || url.trim().isEmpty()) return;
            runOnUiThread(() -> {
                try { android.content.Intent i=new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)); startActivity(i); } catch(Exception ignored) {}
            });
        }

        private String parseTrustedNews(String xml) {
            String[] allowed={"reuters.com","economictimes.indiatimes.com","moneycontrol.com","livemint.com","business-standard.com","financialexpress.com","amfiindia.com","sebi.gov.in","rbi.org.in"};
            String[] sourceNames={"reuters","economic times","moneycontrol","livemint","mint","business standard","financial express","amfi","sebi","reserve bank of india","rbi"};
            Pattern itemP=Pattern.compile("<item>(.*?)</item>",Pattern.DOTALL|Pattern.CASE_INSENSITIVE);
            Matcher im=itemP.matcher(xml); List<String> items=new ArrayList<>();
            while(im.find() && items.size()<40){
                String item=im.group(1); String title=xmlTag(item,"title"), link=xmlTag(item,"link"), date=xmlTag(item,"pubDate");
                Pattern sp=Pattern.compile("<source([^>]*)>(.*?)</source>",Pattern.DOTALL|Pattern.CASE_INSENSITIVE); Matcher sm=sp.matcher(item); String source=""; String sourceUrl=""; if(sm.find()){source=strip(sm.group(2)); Matcher um=Pattern.compile("url=\"([^\"]+)\"",Pattern.CASE_INSENSITIVE).matcher(sm.group(1)); if(um.find()) sourceUrl=um.group(1);}
                String combined=(source+" "+sourceUrl+" "+link).toLowerCase(Locale.ROOT); boolean ok=false; for(String a:allowed){if(combined.contains(a)){ok=true;break;}} if(!ok) for(String n:sourceNames){if(source.toLowerCase(Locale.ROOT).contains(n)){ok=true;break;}}
                if(!ok || title.isEmpty() || link.isEmpty()) continue;
                long ts=0; try{SimpleDateFormat df=new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z",Locale.US);ts=df.parse(date).getTime();}catch(Exception ignored){}
                String rec=ts+"\t"+json(title)+"\t"+json(source)+"\t"+json(date)+"\t"+json(link); items.add(rec);
            }
            items.sort((a,b)->{long ta=0,tb=0;try{ta=Long.parseLong(a.substring(0,a.indexOf('\t')));}catch(Exception ignored){}try{tb=Long.parseLong(b.substring(0,b.indexOf('\t')));}catch(Exception ignored){}return Long.compare(tb,ta);});
            StringBuilder out=new StringBuilder("["); int count=0;
            for(String rec:items){if(count++>0)out.append(',');String[] p=rec.split("\t",-1);out.append("{\"title\":").append(p[1]).append(",\"source\":").append(p[2]).append(",\"date\":").append(p[3]).append(",\"link\":").append(p[4]).append('}');if(count>=20)break;}
            out.append(']'); return out.toString();
        }
        private String xmlTag(String s,String tag){Matcher m=Pattern.compile("<"+tag+"[^>]*>(.*?)</"+tag+">",Pattern.DOTALL|Pattern.CASE_INSENSITIVE).matcher(s);return m.find()?strip(m.group(1)):"";}
        private String strip(String s){return s.replaceAll("<[^>]+>","").replace("&amp;","&").replace("&quot;","\"").replace("&#39;","'").replace("&apos;","'").replace("&lt;","<").replace("&gt;",">").trim();}
        private String json(String s){return "\""+s.replace("\\","\\\\").replace("\"","\\\"").replace("\r"," ").replace("\n"," ")+"\"";}
        private String quoteJs(String s){return json(s);}

    }


    private String getNavText() throws Exception {
        long now = System.currentTimeMillis();
        if (navTextCache != null && now - navCacheTime < CACHE_MS) return navTextCache;
        URL url = new URL("https://portal.amfiindia.com/spages/NAVAll.txt");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setConnectTimeout(15000); c.setReadTimeout(30000); c.setRequestMethod("GET");
        c.setRequestProperty("User-Agent","MF-Bucket-Tracker/11.0");
        c.connect();
        if (c.getResponseCode()!=200) throw new Exception("HTTP "+c.getResponseCode());
        InputStream in=c.getInputStream();
        BufferedReader br=new BufferedReader(new InputStreamReader(in,"UTF-8"));
        StringBuilder sb=new StringBuilder(); String line;
        while((line=br.readLine())!=null) sb.append(line).append('\n');
        br.close(); c.disconnect();
        navTextCache=sb.toString(); navCacheTime=now;
        return navTextCache;
    }

    private String findDirectGrowth(String text, String wanted) {
        String w = wanted.toLowerCase(Locale.ROOT).replace("fund of fund","fof").replace("fund-of-fund","fof");
        String[] tokens=w.replace("-"," ").replace("/"," ").split("\\s+");
        String best=null; int bestScore=-1;
        String[] lines=text.split("\\r?\\n");
        for(String line:lines){
            if(line.trim().isEmpty()) continue;
            String[] f=line.split(";",-1);
            if(f.length<6 || !f[0].trim().matches("\\d+")) continue;
            String name=f[3].trim(); String lower=name.toLowerCase(Locale.ROOT);
            String plan="", option="", nav="", date="";
            if(f.length>=8){plan=f[4].trim(); option=f[5].trim(); nav=f[f.length-2].trim(); date=f[f.length-1].trim();}
            else {nav=f[4].trim(); date=f[5].trim();}
            if(!lower.contains("direct") || !lower.contains("growth")) continue;
            if(plan.length()>0 && !plan.toLowerCase(Locale.ROOT).contains("direct")) continue;
            if(option.length()>0 && !option.toLowerCase(Locale.ROOT).contains("growth")) continue;
            double nv; try{nv=Double.parseDouble(nav);}catch(Exception e){continue;} if(nv<=0)continue;
            int score=0; for(String t:tokens){if(t.length()>2 && lower.contains(t))score+=2;}
            if(lower.contains("direct plan"))score++; if(lower.contains("growth"))score++;
            if(score>bestScore){bestScore=score;best=nav+"\t"+date;}
        }
        return bestScore>=4?best:null;
    }

    private void sendNav(final int b, final int i, final double nav, final String date, final String key, final String error){
        runOnUiThread(() -> {
            if(webView!=null) {
                String js="window.receiveNav("+b+","+i+","+nav+",'"+escapeJs(date)+"','"+escapeJs(key)+"','"+escapeJs(error)+"');";
                webView.evaluateJavascript(js,null);
            }
        });
    }
    private String escapeJs(String s){return s==null?"":s.replace("\\","\\\\").replace("'","\\'").replace("\n"," ").replace("\r"," ");}

    @Override protected void onDestroy(){executor.shutdownNow();super.onDestroy();}
    @Override public void onBackPressed(){if(webView.canGoBack())webView.goBack();else super.onBackPressed();}
}
