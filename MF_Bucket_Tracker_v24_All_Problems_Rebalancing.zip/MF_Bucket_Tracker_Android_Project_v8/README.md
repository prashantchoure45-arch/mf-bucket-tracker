# MF Bucket Tracker v9

Personal MF bucket tracker.

## Locked structure
- Bucket 1: funds + FD (FD only here)
- Bucket 2: ICICI Prudential Multi-Asset 60% + Parag Parikh Conservative Hybrid 40%
- Bucket 3: Parag Parikh Flexi Cap 40% + Axis Multicap 20% + Invesco India Midcap 20% + Bandhan Small Cap 15% + Invesco Global Equity Income FoF 5%
- All MF schemes are Direct Growth.

## Online NAV
Uses AMFI's public daily NAV file from the Android native layer, with a short in-memory cache. NAV is used to calculate estimated units from the amount entered. Actual Kuvera units are not synced.

## Features
Separate Bucket 1/2/3 totals, FD tracker, SIP/lumpsum planner, target-gap allocation, rebalancing, CAGR/XIRR, transaction history, backup/restore, online NAV and estimated units.


V24: includes all prior V22 issue fixes + all-bucket rebalancing + portfolio-level Bucket 1/2/3 allocation targets + profile photo chooser/add-profile fixes + trusted news source parsing/latest-first sorting + readability polish.
