MF Bucket Tracker V28

V28 adds:
- Fixed Target % and Current Amount handling. Entered fund amounts never auto-change because another fund is edited.
- Per-bucket New Amount allocation box: enter one new amount and see the target-percentage split without changing existing holdings.
- Portfolio-level Bucket 1/2/3 target allocation and automatic Current % / Difference / ₹ adjustment.
- Enhanced Rebalancing: overweight vs underweight, ₹ gap, threshold alert, portfolio bucket rebalance, fund-level rebalance, and calculated transfer plan.
- Rebalancing history snapshots now capture All Portfolio + bucket totals + fund amounts while retaining older history entries.
- Existing navigation, profiles, news, NAV, SIP, returns, SWP, goals and backup/restore are preserved.

Actual investments remain in Kuvera; this app is a tracking/calculation tool.
